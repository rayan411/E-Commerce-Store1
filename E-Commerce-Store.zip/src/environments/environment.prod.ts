export const environment = {
  production: true,
  stripePublishableKey: 'pk_test_51RHT5NRxc8HyqXjvCGARPZDmO99SZJu7Ukq3pAzwnhxScMH6c8xGt50d9ndW67tZKCMwcAYwC0AZVhIPnHr0yW4009RbuSFo6'
};
